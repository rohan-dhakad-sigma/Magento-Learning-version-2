<?php
/**
 * @category  Sigma
 * @package   Sigma_Careers
 * @author    SigmaInfo Team
 * @copyright 2022 Sigma (https://www.sigmainfo.net/)
 */

use Magento\Framework\Component\ComponentRegistrar;

ComponentRegistrar::register(ComponentRegistrar::MODULE, 'MageDigest_DemoGraphQl', __DIR__);